let page = 1
const loader = document.getElementById("loader")

function getMovies() {
    loader.classList.remove("hidden")

    const myHeaders = new Headers();
    myHeaders.append("Authorization", "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIxZGI4OTE3NWI4Mjk5MzZjYTgyODVjNDE0NTk4MmExZSIsInN1YiI6IjY0MGVmNzkxZWRlMWIwMDBkOTc1YWZlMCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.a5VcgTce8OeSBvbVbb42XSi8NzzjsR0gkYSs5mtzbQo");

    const requestOptions = {
        method: "GET",
        headers: myHeaders
    };

    fetch(`https://api.themoviedb.org/3/discover/movie?year=2024&language=es-ES&page=${page}`, requestOptions)
        .then((response) => response.json())
        .then((data) => {
            console.log("ENCIMA")
            console.log(data)

            const divMovies = document.getElementById("movies")

            for (const movie of data.results) {
                divMovies.innerHTML += `
           <a href="/detail.html?movie=${movie.id}" class="bg-white rounded shadow p-4">
               <img
                   src="https://image.tmdb.org/t/p/w300${movie.poster_path}"
                   alt=""
               >
               <h1>${movie.title}</h1>
           </a>
       `
            }

            page += 1

            loader.classList.add("hidden")
        })
        .catch((error) => console.error(error));
}

getMovies()