const $title = document.getElementById("title")
const $overview = document.getElementById("overview")

function getDetail(idmovie) {
    const myHeaders = new Headers();
    myHeaders.append("Authorization", "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIxZGI4OTE3NWI4Mjk5MzZjYTgyODVjNDE0NTk4MmExZSIsInN1YiI6IjY0MGVmNzkxZWRlMWIwMDBkOTc1YWZlMCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.a5VcgTce8OeSBvbVbb42XSi8NzzjsR0gkYSs5mtzbQo");

    const requestOptions = {
        method: "GET",
        headers: myHeaders
    };

    fetch(`https://api.themoviedb.org/3/movie/${idmovie}`, requestOptions)
        .then((response) => response.json())
        .then((data) => {
            console.log("ENCIMA")
            console.log(data)

            $title.innerHTML = data.title
            $overview.innerHTML = data.overview

        })
        .catch((error) => console.error(error));
}

const queryString = window.location.search;
const urlParams = new URLSearchParams(queryString);

const idmovie = urlParams.get('movie')
getDetail(idmovie)