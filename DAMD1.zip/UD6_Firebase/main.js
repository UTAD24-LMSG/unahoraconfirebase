
// TODO: Replace the following with your app's Firebase project configuration
// See: https://support.google.com/firebase/answer/7015592
const firebaseConfig = {
    apiKey: "AIzaSyBYSquXU_i_E-Yd6dF4TyLRrrkAFVKHWEQ",
    authDomain: "movies-review-10009.firebaseapp.com",
    projectId: "movies-review-10009",
    storageBucket: "movies-review-10009.appspot.com",
    messagingSenderId: "308965190996",
    appId: "1:308965190996:web:3d7739671fce4ab6ed6cc1"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);


// Initialize Cloud Firestore and get a reference to the service
const db = firebase.firestore();

const COMMENTS = "comments"

function addComment() {
    const $title = document.getElementById("title").value
    const $comment = document.getElementById("comment").value

    const comsg = {
        title: $title,
        comment: $comment
    }

    db.collection(COMMENTS).add(comsg)
        .then((docRef) => {
            console.log("Document written with ID: ", docRef.id);
            loadComments()
        })
        .catch((error) => {
            console.error("Error adding document: ", error);
        });
}

function loadComments() {
    db.collection(COMMENTS).get().then((querySnapshot) => {
        console.log(querySnapshot)
        drawData(querySnapshot)
    });
}

function drawData(allComments) {
    const $list = document.getElementById("list")
    $list.innerHTML = ""

    allComments.forEach(comment => {
        const mResult = `<div class="bg-gray-100 dark:bg-gray-800 rounded-lg p-4 relative">
        <h3 class="text-lg font-medium mb-2">
        ${comment.data().title}
        </h3>
        <p class="text-gray-700 dark:text-gray-300">
           ${comment.data().comment}
        </p>
        <div class="flex justify-between items-center text-gray-500 dark:text-gray-400 text-sm">
            <span>-</span>
            <button
                class="bg-red-500 hover:bg-red-600 text-white font-medium py-1 px-2 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500 dark:bg-red-600 dark:hover:bg-red-700"
            >
                Eliminar
            </button>
        </div>
    </div>`

        $list.innerHTML += mResult
    })
}

loadComments()