let params = new URLSearchParams(location.search);
const movieId = params.get("movie")

const $title = document.getElementById("title")
const $overview = document.getElementById("overview")
const $image = document.getElementById("image")

async function getDetail(idmovie) {
    try {
        const options = {
            method: "GET",
            headers: {
                accept: "application/json",
                Authorization:
                    "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIxZGI4OTE3NWI4Mjk5MzZjYTgyODVjNDE0NTk4MmExZSIsInN1YiI6IjY0MGVmNzkxZWRlMWIwMDBkOTc1YWZlMCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.a5VcgTce8OeSBvbVbb42XSi8NzzjsR0gkYSs5mtzbQo",
            },
        };

        const url =
            `https://api.themoviedb.org/3/movie/${idmovie}`;

        const response = await fetch(url, options);
        const result = await response.json();
        console.log(result)

        $title.innerHTML = result.title
        $overview.innerHTML = result.overview
        $image.src = `https://image.tmdb.org/t/p/w500${result.poster_path}`

        return result.results;
    } catch (error) {
        console.error(err);
        return [];
    }
}

getDetail(movieId)