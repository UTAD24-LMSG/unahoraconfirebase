const $movies = document.getElementById("movies");
let page = 0;
const btnBack = document.getElementById("back");
const btnNext = document.getElementById("next");

const options = {
    method: "GET",
    headers: {
        accept: "application/json",
        Authorization:
            "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIxZGI4OTE3NWI4Mjk5MzZjYTgyODVjNDE0NTk4MmExZSIsInN1YiI6IjY0MGVmNzkxZWRlMWIwMDBkOTc1YWZlMCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.a5VcgTce8OeSBvbVbb42XSi8NzzjsR0gkYSs5mtzbQo",
    },
};

async function getMovies() {
    try {
        const url =
            `https://api.themoviedb.org/3/discover/movie?include_adult=false&include_video=false&language=es-ES&page=${page}&sort_by=popularity.desc`;

        const response = await fetch(url, options);
        const result = await response.json();
        return result.results;
    } catch (error) {
        console.error(err);
        return [];
    }
}

async function loadData(isNext) {
    window.scrollTo(0, 0);

    if (isNext) {
        page += 1
    } else {
        page -= 1
    }

    checkPagination()

    const allMovies = await getMovies();
    $movies.innerHTML = ""
    allMovies.forEach((movie) => {
        // const currMovie = `<img class="w-24 h-24 object-cover" src="https://image.tmdb.org/t/p/w500${movie.poster_path}">`;

        if (!movie.overview) {
            return;
        }

        const currMovie = `<a href="/detail.html?movie=${movie.id}"
    class="group hover:scale-105 hover:shadow-xl transition-all relative overflow-hidden flex bg-white shadow rounded-lg space-x-6 max-h-[150px]"
  >
    <div class="w-1/2 pt-4 px-6 py-4">
      <h1 class="font-bold text-lg line-clamp-1">${movie.title}</h1>
      <p class="text-slate-500 text-sm mt-4 line-clamp-3">
        ${movie.overview}
      </p>
    </div>
    <img
      class="w-1/2 max-h-full object-cover group-hover:scale-125 transition-all"
      src="https://image.tmdb.org/t/p/w500${movie.poster_path}"
      alt=""
      srcset=""
    />
  </a>`;

        $movies.innerHTML += currMovie;
    });

}

loadData(true);


function checkPagination() {
    if (page == 1) {
        btnBack.classList.add("hidden")
    } else {
        btnBack.classList.remove("hidden")
    }
}
