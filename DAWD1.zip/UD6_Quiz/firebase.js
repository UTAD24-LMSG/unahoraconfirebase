const firebaseConfig = {
    apiKey: "AIzaSyADPo_4a1Hztaro_K2UaNcS5l7Z--LxXcE",
    authDomain: "quiz-project-c50ec.firebaseapp.com",
    projectId: "quiz-project-c50ec",
    storageBucket: "quiz-project-c50ec.appspot.com",
    messagingSenderId: "533529237622",
    appId: "1:533529237622:web:918f72d5c993d5fba8e757"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
