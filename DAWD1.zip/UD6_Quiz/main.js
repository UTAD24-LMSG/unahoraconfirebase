
// Initialize Cloud Firestore and get a reference to the service
const db = firebase.firestore();
const QUIZ = "quiz"
let pos = 0
const allQuestions = []

function loadQuestions() {
    db.collection(QUIZ).get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            console.log(`${doc.id} => ${doc.data()}`);
            console.log(doc.data())

            allQuestions.push({ id: doc.id, ...doc.data() })
        });

        setQuestion()
    });
}

function setQuestion() {
    const $title = document.getElementById("title")
    const $answers = document.getElementById("answers")

    const { title, answers } = allQuestions[pos]
    $title.innerText = title

    $answers.innerHTML = ""
    answers.forEach(answer => {
        $answers.innerHTML += ` <button class="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:bg-gray-700 dark:hover:bg-gray-600 dark:text-gray-100">
                                ${answer}
                                </button>`
    })
}

function nextQuestion(isBack = false) {
    if (isBack) {
        pos -= 1
    } else {
        pos += 1
    }
    setQuestion()
}




loadQuestions()