const db = firebase.firestore();
const QUIZ = "quiz"

function loadQuestions() {
    db.collection(QUIZ).get().then((querySnapshot) => {
        drawQuestions(querySnapshot)
    });
}

function drawQuestions(allQuestions) {
    const $questions = document.getElementById("questions")
    $questions.innerHTML = ""
    allQuestions.forEach(q => {
        $questions.innerHTML += `<div class="flex items-center gap-4 p-4">
        <div class="w-4">-.</div>
        <div class="flex-1">${q.data().title}</div>
        <div class="flex-1 grid grid-cols-3 items-center gap-2">
            <div class="flex items-center gap-1">
                <label
                    class="peer-disabled:opacity-70 text-sm font-normal peer-disabled:cursor-not-allowed"
                    for="1-1"
                >
                    ${q.data().answers[0]}
                </label>
            </div>
            <div class="flex items-center gap-1">
                <label
                    class="peer-disabled:opacity-70 text-sm font-normal peer-disabled:cursor-not-allowed"
                    for="1-2"
                >
                ${q.data().answers[1]}
                </label>
            </div>
            <div class="flex items-center gap-1">
                <label
                    class="peer-disabled:opacity-70 text-sm font-normal peer-disabled:cursor-not-allowed"
                    for="1-3"
                >
                ${q.data().answers[2]}
                </label>
            </div>
        </div>
        <div class="w-8">
            <div class="flex items-center justify-center h-full">
               <p>
               ${q.data().correct}
               </p>
            </div>
        </div>
        <button
            class="inline-flex items-center justify-center whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-9 rounded-md px-3"
        >
            Edit
        </button>
        <button
        onclick="deleteQuestion('${q.id}')"
            class="inline-flex items-center justify-center whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-9 rounded-md px-3"
        >
            Delete
        </button>
    </div>
`
    })
}

function addQuestion() {

    const $title = document.getElementById("title").value
    const $correct = document.getElementById("correct").value
    const $answer1 = document.getElementById("answer1").value
    const $answer2 = document.getElementById("answer2").value
    const $answer3 = document.getElementById("answer3").value

    const newQuestion = {
        title: $title,
        correct: $correct,
        answers: [
            $answer1, $answer2, $answer3
        ]
    }

    db.collection(QUIZ).add(newQuestion)
        .then((docRef) => {
            console.log("Document written with ID: ", docRef.id);
            loadQuestions()
        })
        .catch((error) => {
            console.error("Error adding document: ", error);
        });
}

function deleteQuestion(id) {
    db.collection(QUIZ).doc(id).delete().then(() => {
        console.log("Document successfully deleted!");
        loadQuestions()
    }).catch((error) => {
        console.error("Error removing document: ", error);
    });
}


loadQuestions()